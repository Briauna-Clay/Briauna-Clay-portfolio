# Portfolio Website

This is the personal portfolio site for Briauna Clay.

## How to publish on GitHub Pages
1. Create a new GitHub repository (name it something like `portfolio`).
2. Upload the contents of this folder (index.html and images) into the repo.
3. Go to Settings → Pages → Select branch `main` and root folder.
4. Save — your site will be live at `https://your-username.github.io/portfolio/`.

